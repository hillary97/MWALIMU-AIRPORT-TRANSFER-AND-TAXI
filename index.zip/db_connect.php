<?php
$servername = "localhost";
$username = "root";
$password = "";
$database="mwalimutransfer";

$conn=mysqli_connect($servername,$username,$password,$database);
/*
if($conn){
	echo "connection success";
}
else{
	echo "conn failed";
}*/
?>