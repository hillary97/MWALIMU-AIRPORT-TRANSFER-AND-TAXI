<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

     <title>MWALIMU AIRPORT TRANSFER AND TAXI </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
 <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/templatemo-style.css">
     <style type="text/css">
          #contno{
               font-family: "Montserrat Alternates";

               font-size: 31.5px;

               font-weight: 400;

               line-height: 40px;

               color: rgb(51, 51, 51);
          }
          #phonefa{
               color:#ccc;
               background: transparent;
          }
          #menulist a{
               font-family: "Montserrat Alternates";

               font-size: 22px;

               font-weight: 500;

               line-height: 40px;
          }
          p, ul{
               font-size: 1.1em
          }
          
          .navbar-brand {
              width:80%; 
            }
         #pricelogo{
             width:100%;
         }
         #brandimage{
             margin-top:-14px;
         }
          @media only screen and (max-width: 600px) {
            .navbar-brand {
              width:60%; 
            }
            .table{
                font-size:0.8em;
            }
             #pricelogo{
             width:40%;
            }
            #priceheader{
                text-align:center;
            }
            #brandimage{
             margin-top:-22px;
            }
          }
          #caption-text{
            background: rgba(0,0,0,0.3);
            padding: 10px;
            
          }
          .dropdown:hover>.dropdown-menu {
           display: block;
          }
          body {
           background-image: url("images/backcover.jpeg");
           background-repeat: no-repeat;
           background-size: cover;
           background-color: #cccccc;
          }
     </style>

<link href="//www.travelpayouts.com/mewtwo/styles.css?v=002" rel="stylesheet" type="text/css"><style type="text/css">.mewtwo-widget { display: none; }</style><script src="//www.travelpayouts.com/whereami?locale=en&amp;callback=mewtwoForms.geoIPSetter.lang_en"></script><link href="//www.travelpayouts.com/mewtwo/logos.css" rel="stylesheet" type="text/css"><style type="text/css"> .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights { background: #ffffff !important;
    border-color: #c1c1c1 !important;
    border-radius: 2px !important ;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-header__link,
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-link_to_multi { color: #000000 !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-submit_button button { background: #1b9ed9 !important;
    color: #ffffff !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-submit_button button:hover { background: #32a8dd !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-link_to_multi:before { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%2217%22%20height%3D%2216%22%20viewBox%3D%220%200%2017%2016%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ctitle%3Eicon%3C%2Ftitle%3E%3Cpath%20d%3D%22M11.885%202.893c2.242%201.3%203.41%203.22%203.452%205.613-.512-.266-.577-.232-1.12-.24-.157-1.71-.333-2.774-3.19-4.542C9.998%205.497%208.78%205.39%208.395%205.388c-1.475-.013-2.716-1.255-2.73-2.722C5.65%201.2%206.92-.014%208.394%200c1.384.012%202.64%201.125%202.787%202.468%200%200%20.43.264.705.425zM1.208%209.123c.095-2.59%201.242-4.52%203.335-5.683.005.577.066.62.315%201.1-1.436.943-2.294%201.598-2.514%204.95%202.05.08%202.528%201.202%202.706%201.544.68%201.31.167%202.987-1.122%203.688-1.288.7-2.955.15-3.636-1.158-.64-1.228-.246-2.86.87-3.62%200%200%20.033-.502.046-.82zm10.874%205.912c-2.27%201.252-4.515%201.264-6.59.068.493-.3.497-.375.783-.836%201.546.745%202.55%201.143%205.536-.395-.987-1.797-.27-2.786-.068-3.114.77-1.258%202.474-1.682%203.74-.94%201.26.745%201.65%202.457.878%203.714-.724%201.18-2.324%201.684-3.55%201.12%200%200-.448.23-.728.383z%22%20fill%3D%22%23000000%22%20fill-rule%3D%22evenodd%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-swap_button { background-image:
    url("data:image/svg+xml,%3Csvg%20width%3D%2215%22%20height%3D%2213%22%20viewBox%3D%220%200%2015%2013%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ctitle%3ECombined%20Shape%3C%2Ftitle%3E%3Cpath%20d%3D%22M11%204v1.382c0%20.34.276.618.618.618.128%200%20.25-.044.348-.114l2.592-1.98c.082-.058.152-.132.214-.218.382-.512.272-1.238-.236-1.618L11.968.114c-.1-.07-.222-.114-.35-.114-.342%200-.618.276-.618.618V2H4c-.552%200-1%20.446-1%201s.448%201%201%201h7zm-7%207h7c.552%200%201-.446%201-1s-.448-1-1-1H4V7.618C4%207.276%203.724%207%203.382%207c-.128%200-.25.044-.35.114L.464%209.07c-.508.38-.618%201.106-.236%201.618.062.086.132.16.214.218l2.592%201.98c.098.07.22.114.348.114.342%200%20.618-.278.618-.618V11z%22%20fill%3D%22%2300B9FF%22%20fill-rule%3D%22evenodd%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-dates-depart-icons,
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-dates-return-icons { background-image: url("data:image/svg+xml,%3Csvg%20xmlns%3D\'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg\'%20viewBox%3D\'0%200%2015%2017\'%3E%3Cpath%20fill%3D\'%2300B9FF\'%20d%3D\'M0%205v10c0%201.1.9%202%202%202h11c1.1%200%202-.9%202-2V5H0zm5%2010H2v-2h3v2zm0-3H2v-2h3v2zm0-3H2V7h3v2zm4%206H6v-2h3v2zm0-3H6v-2h3v2zm0-3H6V7h3v2zm4%206h-3v-2h3v2zm0-3h-3v-2h3v2zm0-3h-3V7h3v2zM13%202h-1V1c0-.6-.4-1-1-1h-1c-.6%200-1%20.4-1%201v1H6V1c0-.6-.4-1-1-1H4c-.6%200-1%20.4-1%201v1H2C.9%202%200%202.9%200%204h15c0-1.1-.9-2-2-2z\'%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-dates-return-iconsx { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%200%20100%20100%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ctitle%3ESlice%201%3C%2Ftitle%3E%3Cpath%20d%3D%22M98.17%2089.33L58.837%2050l39.33-39.33c2.442-2.442%202.442-6.397%200-8.84-2.438-2.44-6.395-2.44-8.837%200L50%2041.163%2010.67%201.832C8.23-.61%204.272-.61%201.83%201.83c-2.44%202.436-2.44%206.395%200%208.837L41.163%2050%201.832%2089.33c-2.442%202.442-2.442%206.397%200%208.84%202.44%202.44%206.395%202.44%208.837%200L50%2058.837l39.33%2039.33c2.442%202.442%206.4%202.442%208.84%200%202.44-2.44%202.44-6.395%200-8.837z%22%20fill%3D%22%2300B9FF%22%20fill-rule%3D%22evenodd%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-dates-return-iconsx:hover { opacity: 0.7;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-container input[type="text"],
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-trip_class { border-color: #dddddd !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-multi-segment-origin { border-color: #dddddd !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights-trip_class-wrapper:after { background-image: url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2010%206.1%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M10%201.1L8.9%200%205%203.9%201.1%200%200%201.1l5%205%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-spinner div { background: #ffffff !important;
  } </style><style type="text/css"> .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-best_offers { color: #000000 !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers:before { background: linear-gradient(to right, #ffffff, rgba(255,255,255,0)) !important;
  }


  .mewtwo-flights--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers:after,


  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers:after { background: linear-gradient(to top, #ffffff, rgba(255,255,255,0)) !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-show_hotels-wrapper { background: #ffffff !important;
  }

  .mewtwo-flights--xs .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-show_hotels-wrapper:after,
  .mewtwo-hotels--xs .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-show_hotels-wrapper:after { background: linear-gradient(to bottom, #ffffff, rgba(255,255,255,0)) !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-show_hotels__label { color: #000000 !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-show_hotels-wrapper:before,
  .mewtwo-hotels--xs .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers-item-link__price:before,
  .mewtwo-flights--xs .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers-item-link__price:before { background: linear-gradient(to left, #ffffff, rgba(255,255,255,0)) !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers-item-link__price { background: #ffffff !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-best_offers_plane--ow { background: no-repeat url("data:image/svg+xml,%3Csvg%20id%3D%22All_glyphs%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%22230%20113%2021.6%2020.3%22%3E%3Cstyle%3E.st0%7Bfill%3A%23000000%3B%7D%3C%2Fstyle%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M235.8%20133.3h2.2l4.8-8.6h5.6s3.2%200%203.2-1.5-3.2-1.5-3.2-1.5h-5.6l-4.8-8.6h-2.2l2.7%208.6h-3.9l-2.4-2.2H230l1.7%203.7-1.7%203.7h2.2l2.4-2.2h3.9l-2.7%208.6z%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-best_offers_plane--rt { background: no-repeat url("data:image/svg+xml,%3Csvg%20id%3D%22All_glyphs%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%22230%20113%2027.5%2036.6%22%3E%3Cstyle%3E.st0%7Bfill%3A%23000000%3B%7D%3C%2Fstyle%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M235.8%20133.3h2.2l4.8-8.6h5.6s3.2%200%203.2-1.5-3.2-1.5-3.2-1.5h-5.6l-4.8-8.6h-2.2l2.7%208.6h-3.9l-2.4-2.2H230l1.7%203.7-1.7%203.7h2.2l2.4-2.2h3.9l-2.7%208.6zM251.7%20149.6h-2.2l-4.8-8.6h-5.6s-3.2%200-3.2-1.5%203.2-1.5%203.2-1.5h5.6l4.8-8.6h2.2L249%20138h3.9l2.4-2.2h2.2l-1.7%203.7%201.7%203.7h-2.2l-2.4-2.2H249l2.7%208.6z%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-custom_checkbox { background: #fff no-repeat url("data:image/svg+xml,%3Csvg%20id%3D%22Layer_1%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%208.5%206%22%3E%3Cstyle%3E.st0%7Bfill%3A%2300B9FF%3B%7D%3C%2Fstyle%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M8.5%201.1L7.4%200%203.6%203.8%201.1%201.3%200%202.4%203.6%206z%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-custom_checkbox_wrapper { border: 1px solid #000000 !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers_list { -webkit-animation-duration: s !important;
    animation-duration: s !important;
  }

  .mewtwo-flights--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-flights .mewtwo-best_offers_list { -webkit-animation-duration: s !important;
    animation-duration: s !important;
  } </style><style type="text/css"> .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-custom_checkbox { background-image: url("data:image/svg+xml,%3Csvg%20id%3D%22Layer_1%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%208.5%206%22%3E%3Cstyle%3E.st0%7Bfill%3A%2300B9FF%3B%7D%3C%2Fstyle%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M8.5%201.1L7.4%200%203.6%203.8%201.1%201.3%200%202.4%203.6%206z%22%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-custom_checkbox_wrapper { border-color: #00B9FF !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-passengers .mewtwo-popup-ages-counter__plus { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%2014%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%206h14v2H0z%22%2F%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M6%200h2v14H6z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-passengers .mewtwo-popup-ages-counter__plus:hover { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%2014%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%206h14v2H0z%22%2F%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M6%200h2v14H6z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-passengers .mewtwo-popup-ages-counter__minus { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%202%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%200h14v2H0z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-passengers .mewtwo-popup-ages-counter__minus:hover { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%202%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%200h14v2H0z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-passengers .mewtwo-passengers-ready__button { background-color: #1b9ed9 !important;
    color: #ffffff !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-passengers .mewtwo-popup_header { background-color: #00B9FF !important;
  } </style><style type="text/css"> .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active .mewtwo-autocomplete-list-item-info__right_block { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active .mewtwo-autocomplete-list-item-info__right_block:before { background: linear-gradient(to left, #00B9FF, rgba(0,185,255,0)) !important;
  } </style><style type="text/css"> .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active .mewtwo-autocomplete-list-item-info__right_block { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active .mewtwo-autocomplete-list-item-info__right_block:before { background: linear-gradient(to left, #00B9FF, rgba(0,185,255,0)) !important;
  } </style><style type="text/css"> .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-current:hover div{ background: #00B9FF !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-simple .mewtwo-datepicker-table .mewtwo-datepicker-selected div { background: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div:hover { background: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div:hover { background: #00B9FF 0 0 no-repeat url("data:image/svg+xml,%3Csvg%20version%3D'1.2'%20baseProfile%3D'tiny'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2026%2022'%3E%3Cpath%20fill%3D'%2300B9FF'%20d%3D'M4.3%2022H26V0H4.3L0%2011z'%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%224%22%20height%3D%225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%3E%3Cuse%20xlink%3Ahref%3D%22%23path0_fill%22%20fill%3D%22%2300B9FF%22%2F%3E%3Cdefs%3E%3Cpath%20id%3D%22path0_fill%22%20fill-rule%3D%22evenodd%22%20d%3D%22M2%203.993c1.105%200%202-.894%202-1.996A1.998%201.998%200%200%200%202%200C.895%200%200%20.894%200%201.997c0%201.102.895%201.996%202%201.996z%22%20transform%3D%22translate(0%20.364)%22%2F%3E%3C%2Fdefs%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--midMin .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div,
  .mewtwo-modal--min .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div,
  .mewtwo-modal--micro .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div { background-image: none !important;
    border-bottom: 1px solid #00B9FF !important;
  }

  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-start-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-start-sausage div:hover,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-end-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-end-sausage div:hover,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div:hover,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div:hover { background: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-next,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-prev { color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-prev-month-control,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-next-month-control { background-image: url("data:image/svg+xml,%3Csvg%20version%3D'1.2'%20baseProfile%3D'tiny'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2030.6%2024.6'%3E%3Cpath%20fill%3D'%2300B9FF'%20d%3D'M.6%2010.8l.2-.2%209.9-10c.8-.8%202.2-.8%203%200l.3.2c.8.8.8%202.2%200%203L7.9%2010h20.6c1.2%200%202.1%201%202.1%202.1v.3c0%201.2-1%202.1-2.1%202.1H7.9l6.2%206.2c.8.8.8%202.2%200%203l-.3.3c-.8.8-2.2.8-3%200L.8%2014l-.2-.2c-.8-.8-.8-2.2%200-3z'%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--micro .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-container-return_button__text { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%200%20100%20100%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ctitle%3ESlice%201%3C%2Ftitle%3E%3Cpath%20d%3D%22M98.17%2089.33L58.837%2050l39.33-39.33c2.442-2.442%202.442-6.397%200-8.84-2.438-2.44-6.395-2.44-8.837%200L50%2041.163%2010.67%201.832C8.23-.61%204.272-.61%201.83%201.83c-2.44%202.436-2.44%206.395%200%208.837L41.163%2050%201.832%2089.33c-2.442%202.442-2.442%206.397%200%208.84%202.44%202.44%206.395%202.44%208.837%200L50%2058.837l39.33%2039.33c2.442%202.442%206.4%202.442%208.84%200%202.44-2.44%202.44-6.395%200-8.837z%22%20fill%3D%22%2300B9FF%22%20fill-rule%3D%22evenodd%22%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker .mewtwo-popup_header { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker .mewtwo-popup_header span { } </style><style type="text/css"> .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels { background: #ffffff !important;
    border-color: #c1c1c1 !important;
    border-radius: 2px !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-header__link { color: #000000 !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-submit_button button { background: #1b9ed9 !important;
    color: #ffffff !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-submit_button button:hover { background: #32a8dd !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-dates-checkin-icons,
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-dates-checkout-icons { background-image: url("data:image/svg+xml,%3Csvg%20xmlns%3D\'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg\'%20viewBox%3D\'0%200%2015%2017\'%3E%3Cpath%20fill%3D\'%2300B9FF\'%20d%3D\'M0%205v10c0%201.1.9%202%202%202h11c1.1%200%202-.9%202-2V5H0zm5%2010H2v-2h3v2zm0-3H2v-2h3v2zm0-3H2V7h3v2zm4%206H6v-2h3v2zm0-3H6v-2h3v2zm0-3H6V7h3v2zm4%206h-3v-2h3v2zm0-3h-3v-2h3v2zm0-3h-3V7h3v2zM13%202h-1V1c0-.6-.4-1-1-1h-1c-.6%200-1%20.4-1%201v1H6V1c0-.6-.4-1-1-1H4c-.6%200-1%20.4-1%201v1H2C.9%202%200%202.9%200%204h15c0-1.1-.9-2-2-2z\'%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-city-icon { background-image: url("data:image/svg+xml,%3Csvg%20xmlns%3D\'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg\'%20viewBox%3D\'-534.7%20251%2074.1%2069.3\'%3E%3Cg%20fill%3D\'%2300B9FF\'%3E%3Cpath%20d%3D\'M-477.8%20303.1c-4.7%200-9%201.9-12.1%205%203.3%202.2%204.9%206.3%203.8%2012.2h25.4c0-9.5-7.7-17.2-17.1-17.2zM-496.9%20309.5c-6%200-10.8%204.8-10.8%2010.8h21.6c0-6-4.8-10.8-10.8-10.8zM-470.5%20255.1v-4.3H-485v4.3h-9.3l.1%202v28.7l4.5%204.4v-30.4h5v38.4h4.5v-38.4h5v38.4h4.5v-38.4h5.3v41.6l4.7%204.1v-50.4\'%2F%3E%3Cpath%20d%3D\'M-493.6%20305.1l.4-.4c1.1-1.1%202.4-2.1%203.7-2.9v-3.6l-7.3-7.6H-516v29.6h3.7c0-8.5%207-15.5%2015.5-15.5%201%20.1%202.1.2%203.2.4zM-534.7%20279.1v41.1H-521.1v-41.1l-6.8-16.7-6.8%2016.7zm10.2%206.7c0%201.9-1.5%203.4-3.4%203.4s-3.4-1.5-3.4-3.4%201.5-3.4%203.4-3.4%203.4%201.5%203.4%203.4z\'%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-container input[type="text"]{ border-color: #dddddd !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-guests:after { background-image: url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2010%206.1%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M10%201.1L8.9%200%205%203.9%201.1%200%200%201.1l5%205%22%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item--cities:first-child:before{ background-image: url("data:image/svg+xml,%3Csvg%20width%3D%2210%22%20height%3D%2210%22%20viewBox%3D%220%200%2010%2010%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22%2300B9FF%22%20fill-rule%3D%22evenodd%22%3E%3Cpath%20d%3D%22M3.758%204.984c0%20.686.556%201.243%201.242%201.243.686%200%201.242-.557%201.242-1.243%200-.685-.556-1.242-1.242-1.242-.686%200-1.242.557-1.242%201.242z%22%2F%3E%3Cpath%20d%3D%22M9.66%204.44h-.45C8.957%202.553%207.48%201.064%205.6.795V.3c0-.165-.135-.3-.3-.3h-.6c-.165%200-.3.135-.3.3v.495C2.518%201.065%201.042%202.553.79%204.44H.3c-.165%200-.3.135-.3.3v.6c0%20.165.135.3.3.3h.5c.28%201.85%201.745%203.3%203.6%203.565V9.7c0%20.165.135.3.3.3h.6c.165%200%20.3-.135.3-.3v-.495C7.455%208.94%208.92%207.49%209.2%205.64h.46c.165%200%20.3-.135.3-.3v-.6c0-.165-.135-.3-.3-.3zM5.6%208.21c0-.165-.135-.3-.3-.3h-.6c-.165%200-.3.135-.3.3v.26c-1.452-.25-2.6-1.383-2.867-2.83h.257c.165%200%20.3-.135.3-.3v-.6c0-.165-.135-.3-.3-.3h-.265c.24-1.484%201.397-2.656%202.875-2.91v.26c0%20.165.135.3.3.3h.6c.165%200%20.3-.135.3-.3v-.26c1.478.254%202.636%201.426%202.875%202.91H8.17c-.165%200-.3.135-.3.3v.6c0%20.165.135.3.3.3h.297C8.2%207.087%207.052%208.22%205.6%208.47v-.26z%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item--hotels:first-child:before,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item--cities + .mewtwo-autocomplete-list-item--hotels:before { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%2210%22%20height%3D%2210%22%20viewBox%3D%220%200%2010%2010%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22%2300B9FF%22%20fill-rule%3D%22evenodd%22%3E%3Cpath%20d%3D%22M5.313%200L0%202.51V10h10V3.812L5.312%202.04V0zm4.062%204.23v4.997h-.938v-5.35l.938.353zM4.687.965v8.262h-2.5V2.142l2.5-1.177zm-3.125%201.47v6.792H.625v-6.35l.938-.44zm6.25%201.207v5.585h-2.5V2.7l2.5.942z%22%2F%3E%3Cpath%20d%3D%22M2.9%202.66h1.2v.6H2.9v-.6zM2.9%204.34h1.2v.6H2.9v-.6zM2.9%206.04h1.2v.6H2.9v-.6zM2.9%207.72h1.2v.6H2.9v-.6zM6.1%204.34h1v.6h-1v-.6zM6.1%206.04h1v.6h-1v-.6zM6.1%207.72h1v.6h-1v-.6z%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E") !important;
    background-position: 50% 40%;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active.mewtwo-autocomplete-list-item--cities:first-child:before{ background-image: url("data:image/svg+xml,%3Csvg%20width%3D%2210%22%20height%3D%2210%22%20viewBox%3D%220%200%2010%2010%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22%23FFFFFF%22%20fill-rule%3D%22evenodd%22%3E%3Cpath%20d%3D%22M3.758%204.984c0%20.686.556%201.243%201.242%201.243.686%200%201.242-.557%201.242-1.243%200-.685-.556-1.242-1.242-1.242-.686%200-1.242.557-1.242%201.242z%22%2F%3E%3Cpath%20d%3D%22M9.66%204.44h-.45C8.957%202.553%207.48%201.064%205.6.795V.3c0-.165-.135-.3-.3-.3h-.6c-.165%200-.3.135-.3.3v.495C2.518%201.065%201.042%202.553.79%204.44H.3c-.165%200-.3.135-.3.3v.6c0%20.165.135.3.3.3h.5c.28%201.85%201.745%203.3%203.6%203.565V9.7c0%20.165.135.3.3.3h.6c.165%200%20.3-.135.3-.3v-.495C7.455%208.94%208.92%207.49%209.2%205.64h.46c.165%200%20.3-.135.3-.3v-.6c0-.165-.135-.3-.3-.3zM5.6%208.21c0-.165-.135-.3-.3-.3h-.6c-.165%200-.3.135-.3.3v.26c-1.452-.25-2.6-1.383-2.867-2.83h.257c.165%200%20.3-.135.3-.3v-.6c0-.165-.135-.3-.3-.3h-.265c.24-1.484%201.397-2.656%202.875-2.91v.26c0%20.165.135.3.3.3h.6c.165%200%20.3-.135.3-.3v-.26c1.478.254%202.636%201.426%202.875%202.91H8.17c-.165%200-.3.135-.3.3v.6c0%20.165.135.3.3.3h.297C8.2%207.087%207.052%208.22%205.6%208.47v-.26z%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active.mewtwo-autocomplete-list-item--hotels:first-child:before,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item--cities + .mewtwo-autocomplete-list-item-info--active.mewtwo-autocomplete-list-item--hotels:before { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%2210%22%20height%3D%2210%22%20viewBox%3D%220%200%2010%2010%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22%23FFFFFF%22%20fill-rule%3D%22evenodd%22%3E%3Cpath%20d%3D%22M5.313%200L0%202.51V10h10V3.812L5.312%202.04V0zm4.062%204.23v4.997h-.938v-5.35l.938.353zM4.687.965v8.262h-2.5V2.142l2.5-1.177zm-3.125%201.47v6.792H.625v-6.35l.938-.44zm6.25%201.207v5.585h-2.5V2.7l2.5.942z%22%2F%3E%3Cpath%20d%3D%22M2.9%202.66h1.2v.6H2.9v-.6zM2.9%204.34h1.2v.6H2.9v-.6zM2.9%206.04h1.2v.6H2.9v-.6zM2.9%207.72h1.2v.6H2.9v-.6zM6.1%204.34h1v.6h-1v-.6zM6.1%206.04h1v.6h-1v-.6zM6.1%207.72h1v.6h-1v-.6z%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E") !important;
  } </style><style type="text/css"> .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-best_offers { color: #000000 !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers:before { background: linear-gradient(to right, #ffffff, rgba(255,255,255,0)) !important;
  }

  .mewtwo-hotels--s
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers:after,

  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers:after,

  .mewtwo-hotels--s
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers:after,

  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers:after { background: linear-gradient(to top, #ffffff, rgba(255,255,255,0)) !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-show_hotels-wrapper { background: #ffffff !important;
  }

  .mewtwo-hotels--s
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-show_hotels-wrapper:after,

  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-show_hotels-wrapper:after,

  .mewtwo-hotels--s
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-show_hotels-wrapper:after,

  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-show_hotels-wrapper:after { background: linear-gradient(to bottom, #ffffff, rgba(255,255,255,0)) !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-show_hotels-wrapper:before,

  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers-item-link__price:before,

  .mewtwo-hotels--s
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers-item-link__price:before,

  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers-item-link__price:before,

  .mewtwo-hotels--s
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers-item-link__price:before { background: linear-gradient(to left, #ffffff, rgba(255,255,255,0)) !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers-item-link__price { background: #ffffff !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-best_offers_plane--ow { background: no-repeat url("data:image/svg+xml,%3Csvg%20id%3D%22All_glyphs%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%22230%20113%2021.6%2020.3%22%3E%3Cstyle%3E.st0%7Bfill%3A%23000000%3B%7D%3C%2Fstyle%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M235.8%20133.3h2.2l4.8-8.6h5.6s3.2%200%203.2-1.5-3.2-1.5-3.2-1.5h-5.6l-4.8-8.6h-2.2l2.7%208.6h-3.9l-2.4-2.2H230l1.7%203.7-1.7%203.7h2.2l2.4-2.2h3.9l-2.7%208.6z%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-best_offers_plane--rt { background: no-repeat url("data:image/svg+xml,%3Csvg%20id%3D%22All_glyphs%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%22230%20113%2027.5%2036.6%22%3E%3Cstyle%3E.st0%7Bfill%3A%23000000%3B%7D%3C%2Fstyle%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M235.8%20133.3h2.2l4.8-8.6h5.6s3.2%200%203.2-1.5-3.2-1.5-3.2-1.5h-5.6l-4.8-8.6h-2.2l2.7%208.6h-3.9l-2.4-2.2H230l1.7%203.7-1.7%203.7h2.2l2.4-2.2h3.9l-2.7%208.6zM251.7%20149.6h-2.2l-4.8-8.6h-5.6s-3.2%200-3.2-1.5%203.2-1.5%203.2-1.5h5.6l4.8-8.6h2.2L249%20138h3.9l2.4-2.2h2.2l-1.7%203.7%201.7%203.7h-2.2l-2.4-2.2H249l2.7%208.6z%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-custom_checkbox { background: #fff no-repeat url("data:image/svg+xml,%3Csvg%20id%3D%22Layer_1%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%208.5%206%22%3E%3Cstyle%3E.st0%7Bfill%3A%2300B9FF%3B%7D%3C%2Fstyle%3E%3Cpath%20class%3D%22st0%22%20d%3D%22M8.5%201.1L7.4%200%203.6%203.8%201.1%201.3%200%202.4%203.6%206z%22%2F%3E%3C%2Fsvg%3E") !important;
  }
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-custom_checkbox_wrapper { border: 1px solid #000000 !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers_list { -webkit-animation-duration: s !important;
    animation-duration: s !important;
  }

  .mewtwo-hotels--s
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers_list,
  .mewtwo-hotels--xs
  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels .mewtwo-best_offers_list { -webkit-animation-duration: s !important;
    animation-duration: s !important;
  } </style><style type="text/css"> .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active .mewtwo-autocomplete-list-item-info__right_block { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-autocomplete-list-item-info--active .mewtwo-autocomplete-list-item-info__right_block:before { background: linear-gradient(to left, #00B9FF, rgba(0,185,255,0)) !important;
  } </style><style type="text/css"> .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-current:hover div{ background: #00B9FF !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-simple .mewtwo-datepicker-table .mewtwo-datepicker-selected div { background: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div:hover { background: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div:hover { background: #00B9FF 0 0 no-repeat url("data:image/svg+xml,%3Csvg%20version%3D'1.2'%20baseProfile%3D'tiny'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2026%2022'%3E%3Cpath%20fill%3D'%2300B9FF'%20d%3D'M4.3%2022H26V0H4.3L0%2011z'%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%224%22%20height%3D%225%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20xmlns%3Axlink%3D%22http%3A%2F%2Fwww.w3.org%2F1999%2Fxlink%22%3E%3Cuse%20xlink%3Ahref%3D%22%23path0_fill%22%20fill%3D%22%2300B9FF%22%2F%3E%3Cdefs%3E%3Cpath%20id%3D%22path0_fill%22%20fill-rule%3D%22evenodd%22%20d%3D%22M2%203.993c1.105%200%202-.894%202-1.996A1.998%201.998%200%200%200%202%200C.895%200%200%20.894%200%201.997c0%201.102.895%201.996%202%201.996z%22%20transform%3D%22translate(0%20.364)%22%2F%3E%3C%2Fdefs%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--midMin .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div,
  .mewtwo-modal--min .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div,
  .mewtwo-modal--micro .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker.mewtwo-datepicker-range .mewtwo-datepicker-range div { background-image: none !important;
    border-bottom: 1px solid #00B9FF !important;
  }

  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-start-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-start-sausage div:hover,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-end-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-range.mewtwo-datepicker-end-sausage div:hover,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-start-sausage div:hover,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div,
  .mewtwo-modal--popup .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-end-sausage div:hover { background: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-next,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-table .mewtwo-datepicker-prev { color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-prev-month-control,
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-next-month-control { background-image: url("data:image/svg+xml,%3Csvg%20version%3D'1.2'%20baseProfile%3D'tiny'%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2030.6%2024.6'%3E%3Cpath%20fill%3D'%2300B9FF'%20d%3D'M.6%2010.8l.2-.2%209.9-10c.8-.8%202.2-.8%203%200l.3.2c.8.8.8%202.2%200%203L7.9%2010h20.6c1.2%200%202.1%201%202.1%202.1v.3c0%201.2-1%202.1-2.1%202.1H7.9l6.2%206.2c.8.8.8%202.2%200%203l-.3.3c-.8.8-2.2.8-3%200L.8%2014l-.2-.2c-.8-.8-.8-2.2%200-3z'%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--micro .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker-container-return_button__text { background-image: url("data:image/svg+xml,%3Csvg%20width%3D%22100%22%20height%3D%22100%22%20viewBox%3D%220%200%20100%20100%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Ctitle%3ESlice%201%3C%2Ftitle%3E%3Cpath%20d%3D%22M98.17%2089.33L58.837%2050l39.33-39.33c2.442-2.442%202.442-6.397%200-8.84-2.438-2.44-6.395-2.44-8.837%200L50%2041.163%2010.67%201.832C8.23-.61%204.272-.61%201.83%201.83c-2.44%202.436-2.44%206.395%200%208.837L41.163%2050%201.832%2089.33c-2.442%202.442-2.442%206.397%200%208.84%202.44%202.44%206.395%202.44%208.837%200L50%2058.837l39.33%2039.33c2.442%202.442%206.4%202.442%208.84%200%202.44-2.44%202.44-6.395%200-8.837z%22%20fill%3D%22%2300B9FF%22%20fill-rule%3D%22evenodd%22%2F%3E%3C%2Fsvg%3E") !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker .mewtwo-popup_header { background-color: #00B9FF !important;
  }
  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-datepicker .mewtwo-popup_header span { } </style><style type="text/css"> .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-guests .mewtwo-popup-ages-counter__plus { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%2014%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%206h14v2H0z%22%2F%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M6%200h2v14H6z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-guests .mewtwo-popup-ages-counter__plus:hover { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%2014%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%206h14v2H0z%22%2F%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M6%200h2v14H6z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-guests .mewtwo-popup-ages-counter__minus { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%202%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%200h14v2H0z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-guests .mewtwo-popup-ages-counter__minus:hover { background-image: url('data:image/svg+xml,%3Csvg%20version%3D%221.2%22%20baseProfile%3D%22tiny%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2014%202%22%3E%3Cpath%20fill%3D%22%2300B9FF%22%20d%3D%22M0%200h14v2H0z%22%2F%3E%3C%2Fsvg%3E') !important;
  }

  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-guests .mewtwo-guests-success_button .mewtwo-popup_apply_button--mobile { background-color: #1b9ed9 !important;
    color: #ffffff !important;
  }


  .mewtwo-modal--3175e5c7d102c1dc109933804cb891d3 .mewtwo-guests .mewtwo-popup_header { background-color: #00B9FF !important;
  }

  .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-hotels-guests { border-color: #dddddd !important;
  } </style></head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50" data-inited_widgets="3175e5c7d102c1dc109933804cb891d3">
     <!-- MENU -->
     <div style="background-color:blue;height: 6px" class="fluid-container"></div>
    <div  class="container">
        <header>
            <h1 style="text-align:center;padding-top:20px;color:red;padding-bottom:5px;font-weight:bold;font-family: verdana"><img style="padding-bottom: 0px;" src="images/mlogo.PNG" width="200" height="100">&nbsp;&nbsp;&nbsp;Mwalimu Airport <span style="color:darkblue;opacity:1">Transfer AND Taxi</span></h1>
            <div style="width:100%;height: 2px;background-color: black" class=" bg-dark"></div>
        </header>
    <nav>
        <ul class="bg-warning">
            <li><a style="transition: .6s " class="" href="index.php">Taxis</a></li>
            <li><a href="carhire.php">CarHire</a></li>
            <li><a class="text-white" href="flight.php">Flights</a></li>
            <li><a  href="gallery.php">Gallery</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="review.php">Reviews</a></li>
            <li><i style="font-size:30px" class='fa fa-phone'></i><a style="color:black;font-family: roboto mono;font-size:30px" href="#">+254 723 234 262 </a></li>
        </ul>
    </nav>
</div>

     <section style="background: ;padding: 0px 4%">
          <div class="container">
               <div class="row">
                    <div class="col-md-12 col-sm-12">
                    <h2 style="color: gray">Find Cheap Flights</h2> 
                    </div>
                  </div>
          </div>
      </section>

     
      <section style="padding-bottom: 5px;padding-top: 8%;padding-bottom:3%">
          <div class="container">
          <div class="row">
              
           <script async="" src="//st.avsplow.com/19.18.9/sp.js"></script><script charset="utf-8" type="text/javascript">
            window.TP_FORM_SETTINGS = window.TP_FORM_SETTINGS || {};
            window.TP_FORM_SETTINGS["3175e5c7d102c1dc109933804cb891d3"] = {
            "handle": "3175e5c7d102c1dc109933804cb891d3",
            "widget_name": "Search form #3",
            "border_radius": "2",
            "additional_marker": null,
            "width": 822,
            "show_logo": true,
            "show_hotels": true,
            "form_type": "avia_hotel",
            "locale": "en",
            "currency": "usd",
            "sizes": "default",
            "search_target": "_blank",
            "active_tab": "avia",
            "search_host": "www.aviasales.com/search",
            "hotels_host": "search.hotellook.com",
            "hotel": "",
            "hotel_alt": "Hotellook - best prices on hotels worldwide. Compare prices across 30 booking websites and save on your hotel.",
            "avia_alt": "",
            "retargeting": true,
            "trip_class": "economy",
            "depart_date": null,
            "return_date": null,
            "check_in_date": null,
            "check_out_date": null,
            "no_track": false,
            "powered_by": true,
            "source_id": 62216,
            "id": 250977,
            "marker": 319712,
            "origin": {
                "name": ""
            },
            "destination": {
                "name": ""
            },
            "color_scheme": {
                "name": "white_blue",
                "icons": "icons_blue",
                "background": "#ffffff",
                "color": "#000000",
                "border_color": "#c1c1c1",
                "button": "#1b9ed9",
                "button_text_color": "#ffffff",
                "input_border": "#ffffff"
            },
            "hotels_type": "hotellook_host",
            "best_offer": {
                "locale": "en",
                "currency": "usd",
                "marker": 319712,
                "search_host": "www.aviasales.com/search",
                "offers_switch": false,
                "api_url": "//minprices-jetradar.aviasales.ru/minimal_prices/offers.json",
                "routes": []
            },
            "hotel_logo_host": null,
            "search_logo_host": "jetradar.com",
            "hotel_marker_format": null,
            "hotelscombined_marker": null,
            "sources": [
                {
                    "id": 62216,
                    "name": "Starter Traffic Source"
                }
            ],
            "responsive": false,
            "height": 245
        };
        </script>
        <script initialized="true" script-initialized="true" src="https://www.travelpayouts.com/widgets_static/3175e5c7d102c1dc109933804cb891d3.js?v=2175"></script><div class="mewtwo-flights--l mewtwo-hotels--l" style="max-width: 822px !important; position: relative;"><div class="mewtwo-widget mewtwo-widget--3175e5c7d102c1dc109933804cb891d3"><nav class="mewtwo-tabs "><style type="text/css"> .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item { background-color: #e6e6e6 !important;
      color: #000000 !important;
    }

    .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item span { color: #000000 !important;
    }

    .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item:first-child { border-top-left-radius: 2px !important ;
    }

    .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item:last-child { border-top-right-radius: 2px !important ;
    }

    .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item.mewtwo-tabs-tabs_list__item--active { background-color: #ffffff !important;
      border: 1px solid #c1c1c1 !important;
    }
    .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item--active:after { background-color: #ffffff !important;
    }

    .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item--hotels:before { background-image: url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20690%20340%22%3E%3Cg%20fill%3D%22%23000000%22%3E%3Cpath%20d%3D%22M86.2%2014.2C86.2%206.6%2092.8%200%20100.4%200h21.8c8.1%200%2014.7%206.6%2014.7%2014.2v311.1c0%208.1-6.6%2014.2-14.2%2014.2h-22.3c-7.6.5-14.2-5.6-14.2-13.7V14.2zM552.6%20133c0-8.1%206.6-14.2%2014.2-14.2h21.8c8.1%200%2014.2%206.6%2014.2%2014.2v192.8c0%208.1-6.6%2014.2-14.2%2014.2h-21.8c-8.1%200-14.2-6.6-14.2-14.2V133zM170.9%20182.7c-8.1%200-14.2-6.6-14.2-14.2v-21.8c0-8.1%206.6-14.2%2014.2-14.2h102c8.1%200%2014.2%206.6%2014.2%2014.2v21.8c0%208.1-6.6%2014.2-14.2%2014.2h-102z%22%2F%3E%3Cpath%20d%3D%22M111.6%20200.4H578v70.5H111.6z%22%2F%3E%3Ccircle%20cx%3D%22221.7%22%20cy%3D%22111.1%22%20r%3D%2246.2%22%2F%3E%3Cpath%20d%3D%22M532.3%20119.8c0-7.1-4.6-13.2-11.2-15.7-28.9-9.6-113.7-33-198.9-31-9.1%200-16.2%207.6-16.2%2016.7v92.9h225.8v-62.9h.5z%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E") !important;
    }
    .mewtwo-widget--3175e5c7d102c1dc109933804cb891d3 .mewtwo-tabs-tabs_list__item.mewtwo-tabs-tabs_list__item--flights:before { background-image: url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20690%20340%22%3E%3Cpath%20fill%3D%22%23000000%22%20d%3D%22M261%2C340h36.2l81.2-144.7h93.3c0%2C0%2C54.2%2C0%2C54.2-25.3s-54.2-25.3-54.2-25.3h-93.4L297%2C0h-36.2l45%2C144.7H241%20l-40.7-36.2h-36.2L193%2C170l-28.9%2C61.5h36.2l40.7-36.2h65L261%2C340z%22%2F%3E%3C%2Fsvg%3E")  !important;
    } </style><ul class="mewtwo-tabs_list"><li class="mewtwo-tabs-tabs_list__item mewtwo-tabs-tabs_list__item--count2 mewtwo-tabs-tabs_list__item--flights mewtwo-tabs-tabs_list__item--active" role="tab--3175e5c7d102c1dc109933804cb891d3" data-tab="flights"><span role="tab--3175e5c7d102c1dc109933804cb891d3" data-tab="flights">FLIGHTS</span></li><li class="mewtwo-tabs-tabs_list__item mewtwo-tabs-tabs_list__item--count2 mewtwo-tabs-tabs_list__item--hotels" role="tab--3175e5c7d102c1dc109933804cb891d3" data-tab="hotels"><span role="tab--3175e5c7d102c1dc109933804cb891d3" data-tab="hotels">HOTELS</span></li></ul><!--if--></nav><section class="mewtwo-flights mewtwo-flights--virgin mewtwo-tabs-container"><div class="mewtwo-flights-container mewtwo-flights-container--new" role="flights"><header class="mewtwo-flights-header mewtwo-flights-header--en mewtwo-flights-header--light"><a href="//www.jetradar.com/?marker=319712" class="mewtwo-flights-header__link_logo" target="_blank" role="logo"></a><a href="//www.jetradar.com/?marker=319712" class="mewtwo-flights-header__link" target="_blank" role="logo"> Cheap flights and airline tickets </a></header><!--if--><form accept-charset="utf-8" id="flights-form-3175e5c7d102c1dc109933804cb891d3" action="https://www.aviasales.com/search" target="_blank"><div><input type="hidden" name="marker" value="319712"><!--for--></div><div class="mewtwo-flights-origin"><input type="text" name="origin_name" autocomplete="off" required="" id="flights-origin-prepop-3175e5c7d102c1dc109933804cb891d3" placeholder="Origin" data-label="Origin" role="flights-origin" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3" data-placeholder-initialized="true" class="mewtwo-filled"><label for="flights-origin-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Origin</label><input type="hidden" name="origin_iata" id="flights-origin-3175e5c7d102c1dc109933804cb891d3" value="NBO"><div class="mewtwo-flights-origin-country mewtwo-flights-origin-country--new" role="flights-origin_details" style="visibility: visible;"><span class="mewtwo-flights-origin-country__pseudo" role="flights-origin_country__pseudo">Nairobi</span><span class="mewtwo-flights-origin-country__name" role="flights-origin_country__name">,&nbsp;Kenya</span></div><div class="mewtwo-flights-origin__iata mewtwo-flights-origin__iata--new" role="flights-origin_right_block">NBO</div><div class="mewtwo-swap_button" role="swap_button"></div><!--if--><div class="mewtwo-autocomplete-spinner" role="autocomplete-spinner"><div></div><div></div><div></div></div></div><!--PlaceInput--><div class="mewtwo-flights-destination"><input type="text" name="destination_name" autocomplete="off" required="" id="flights-destination-prepop-3175e5c7d102c1dc109933804cb891d3" placeholder="Destination" data-label="Destination" role="flights-destination" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3" data-placeholder-initialized="true"><label for="flights-destination-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Destination</label><input type="hidden" name="destination_iata" id="flights-destination-3175e5c7d102c1dc109933804cb891d3" value=""><div class="mewtwo-flights-destination-country mewtwo-flights-destination-country--new" role="flights-destination_details"><span class="mewtwo-flights-destination-country__pseudo" role="flights-destination_country__pseudo"></span><span class="mewtwo-flights-destination-country__name" role="flights-destination_country__name"></span></div><div class="mewtwo-flights-destination__iata mewtwo-flights-destination__iata--new" role="flights-destination_right_block"></div><!--if--><div class="mewtwo-autocomplete-spinner" role="autocomplete-spinner"><div></div><div></div><div></div></div></div><!--PlaceInput--><div class="mewtwo-flights-dates mewtwo-flights-dates--new"><div class="mewtwo-flights-dates-depart "><input type="text" placeholder="Depart date" data-label="Depart date" id="flights-dates-depart-prepop-3175e5c7d102c1dc109933804cb891d3" data-datepicker-sameday="false" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3" role="flights-dates-depart" data-popup-max-height="246" data-popup-min-height="184" data-linked-id="flights-dates-return-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-datepicker-trigger mewtwo-filled" readonly="true" data-placeholder-initialized="true"><label for="flights-dates-depart-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Depart date</label><input type="hidden" role="flights-dates-depart-value" value="2022-03-07" id="flights-dates-depart-3175e5c7d102c1dc109933804cb891d3" name="depart_date"><!--if--><div class="mewtwo-flights-dates-depart-icons mewtwo-input-icons"></div></div><!--DatepickerInput--><div class="mewtwo-flights-dates-return mewtwo-flights-dates-return--filled "><input type="text" placeholder="Return date" data-label="Return date" id="flights-dates-return-prepop-3175e5c7d102c1dc109933804cb891d3" data-datepicker-sameday="true" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3" role="flights-dates-return" data-popup-max-height="311" data-popup-min-height="224" data-linked-id="flights-dates-depart-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-datepicker-trigger mewtwo-filled" readonly="true" data-placeholder-initialized="true"><label for="flights-dates-return-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Return date</label><input type="hidden" role="flights-dates-return-value" value="2022-03-14" id="flights-dates-return-3175e5c7d102c1dc109933804cb891d3" name="return_date"><div class="mewtwo-flights-dates-return-iconsx mewtwo-input-icons" role="flights-dates-return-clear"></div><!--if--><div class="mewtwo-flights-dates-return-icons mewtwo-input-icons"></div></div><!--DatepickerInput--></div><div class="mewtwo-flights-trip_class" role="passengers" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3"><input type="hidden" placeholder="Passengers/Class" class="mewtwo-flights-trip_class__passengers" role="passengers_amount" data-placeholder-initialized="true" id="input-with-placeholder-0__handle--3175e5c7d102c1dc109933804cb891d3"><label for="input-with-placeholder-0__handle--3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Passengers/Class</label><div class="mewtwo-flights-trip_class-wrapper mewtwo-flights-trip_class-wrapper--new"><div class="mewtwo-flights-trip_class__passengers" role="passengers_amount">1 passenger</div><div class="mewtwo-flights-trip_class__class">economy сlass</div></div></div><div class="mewtwo-flights-submit_button mewtwo-flights-submit_button--new"><button role="flights_submit" type="submit">Search</button></div><!--if--><input type="hidden" name="with_request" value="true"><input type="hidden" name="adults" value="1"><input type="hidden" name="children" value="0"><input type="hidden" name="infants" value="0"><input type="hidden" name="trip_class" value="0"><input type="hidden" name="locale" value="en"><input type="hidden" name="one_way" value="false"><input type="hidden" name="currency" value="usd"><!--if--><input type="hidden" name="ct_guests" id="flights-ct-guests-3175e5c7d102c1dc109933804cb891d3" value="1 passenger"><input type="hidden" name="ct_rooms" value="1" id="flights-ct-rooms-3175e5c7d102c1dc109933804cb891d3"></form><section class="mewtwo-best_offers  mewtwo-best_offers--hidden"><header class="mewtwo-show_hotels-wrapper"><div class="mewtwo-show_hotels"><input type="checkbox" class="mewtwo-show_hotels-checkbox" id="flights_show_hotels_id--3175e5c7d102c1dc109933804cb891d3" role="show_hotels"><div class="mewtwo-custom_checkbox_wrapper"><span class="mewtwo-custom_checkbox"></span></div><label class="mewtwo-show_hotels__label" for="flights_show_hotels_id--3175e5c7d102c1dc109933804cb891d3"> Show hotels </label></div></header><div style="z-index: 1 !important; display: block; align-items: center !important; margin-top: 5px !important; margin-bottom: 5px !important;" class="tp_powered_by"><a style="
display: inline-block !important;
height:16px !important;
background: none !important;
background-color: transparent !important;
border: 0 !important;
box-shadow: none !important;
box-sizing: border-box !important;
color: none !important;
cursor:pointer !important;
margin: 0 !important;
vertical-align: baseline !important;
text-align: left !important;
text-decoration: none !important;
text-indent: 0 !important;
text-transform: none !important;
text-shadow: none !important;
white-space: normal !important;
letter-spacing: 0 !important;
float: none !important;
font: inherit !important;
font-style: normal !important;
font-weight: normal !important;
font-size: 100% !important;
line-height: 1 !important;
padding: 0 !important;
position: initial !important;
" href="//www.travelpayouts.com?marker=319712.poweredby&amp;utm_source=powered_by&amp;utm_medium=widget&amp;utm_campaign=mewtwo" rel="nofollow" target="_blank"><img width="167" height="16" alt="powered_by" src="https://www.travelpayouts.com/powered_by/img/tp.png" style="opacity:0.4;padding:0 5px !important;box-sizing: content-box !important;" onmouseover="this.style['opacity'] = 1" onmouseout="this.style['opacity'] = 0.4"></a></div></section></div></section><section class="mewtwo-hotels mewtwo-hotels--virgin mewtwo-tabs-container--hidden mewtwo-tabs-container--transparent mewtwo-tabs-container"><div class="mewtwo-hotels-container" role="hotels"><header class="mewtwo-hotels-header mewtwo-hotels-header--light"><a href="https://hotellook.com/?marker=319712&amp;language=en" class="mewtwo-hotels-header__link_logo" target="_blank" role="logo"></a><a href="https://hotellook.com/?marker=319712&amp;language=en" class="mewtwo-hotels-header__link" target="_blank" role="logo"> Search and compare hotel prices </a></header><!--if--><form role="hotels-form" accept-charset="utf-8" id="hotels-form-3175e5c7d102c1dc109933804cb891d3" action="https://search.hotellook.com" target="_blank"><div></div><div class="mewtwo-hotels-city mewtwo-hotels-city--new mewtwo-stand-out"><input type="text" role="place" name="destination" data-label="City or hotel name" placeholder="City or hotel name" autocomplete="off" required="" id="hotels-destination-3175e5c7d102c1dc109933804cb891d3" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3" data-placeholder-initialized="true"><label for="hotels-destination-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">City or hotel name</label><div class="mewtwo-hotels-city-location" role="place_details"><span class="mewtwo-hotels-city-location__pseudo"></span><span class="mewtwo-hotels-city-location__name"></span></div><div class="mewtwo-hotels-city-icon"></div></div><div class="mewtwo-hotels-dates mewtwo-hotels-dates--new"><div class="mewtwo-hotels-dates-checkin "><input type="text" placeholder="Check-In" data-label="Check-In" id="hotels-dates-checkin-prepop-3175e5c7d102c1dc109933804cb891d3" data-datepicker-sameday="false" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3" role="hotels-dates-checkin" data-popup-max-height="245" data-popup-min-height="184" data-linked-id="hotels-dates-checkin-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-datepicker-trigger mewtwo-filled" readonly="true" data-placeholder-initialized="true"><label for="hotels-dates-checkin-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Check-In</label><input type="hidden" role="hotels-dates-checkin-value" value="2022-03-07" id="hotels-dates-checkin-3175e5c7d102c1dc109933804cb891d3" name="checkIn"><!--if--><div class="mewtwo-hotels-dates-checkin-icons mewtwo-input-icons"></div></div><!--DatepickerInput--><div class="mewtwo-hotels-dates-checkout  "><input type="text" placeholder="Check-Out" data-label="Check-Out" id="hotels-dates-checkout-prepop-3175e5c7d102c1dc109933804cb891d3" data-datepicker-sameday="false" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3" role="hotels-dates-checkout" data-popup-max-height="245" data-popup-min-height="184" data-linked-id="hotels-dates-checkin-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-datepicker-trigger mewtwo-filled" readonly="true" data-placeholder-initialized="true"><label for="hotels-dates-checkout-prepop-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Check-Out</label><input type="hidden" role="hotels-dates-checkout-value" value="2022-03-14" id="hotels-dates-checkout-3175e5c7d102c1dc109933804cb891d3" name="checkOut"><div class="mewtwo-hotels-dates-checkout-iconsx mewtwo-input-icons" role="hotels-dates-checkout-clear"></div><!--if--><div class="mewtwo-hotels-dates-checkout-icons mewtwo-input-icons"></div></div><!--DatepickerInput--></div><div role="guests" class="mewtwo-hotels-guests mewtwo-hotels-guests--new" data-modal-modifier="3175e5c7d102c1dc109933804cb891d3"><input type="hidden" placeholder="Guests" class="mewtwo-hotels-guests_input mewtwo-filled" id="hotels-guests-3175e5c7d102c1dc109933804cb891d3" value="2 guests" data-placeholder-initialized="true"><label for="hotels-guests-3175e5c7d102c1dc109933804cb891d3" class="mewtwo-placeholder-label">Guests</label><span class="mewtwo-hotels-guests__text mewtwo-like_input">2 guests</span></div><div class="mewtwo-hotels-submit_button mewtwo-hotels-submit_button--new"><button role="hotels_submit" type="submit">Search</button></div><input type="hidden" name="marker" value="319712"><input type="hidden" name="children" value=""><input type="hidden" name="adults" value="2"><input type="hidden" name="language" value="en"><input type="hidden" name="currency" value="usd"><input type="hidden" id="hotels-rooms-3175e5c7d102c1dc109933804cb891d3" value="1"><!--if--><!--if--></form><section class="mewtwo-best_offers  mewtwo-best_offers--hidden"><header class="mewtwo-show_hotels-wrapper"><div class="mewtwo-show_hotels"><input type="checkbox" class="mewtwo-show_hotels-checkbox" role="show_hotels" id="hotels_show_hotels_id--3175e5c7d102c1dc109933804cb891d3"><div class="mewtwo-custom_checkbox_wrapper"><span class="mewtwo-custom_checkbox"></span></div><label class="mewtwo-show_hotels__label" for="hotels_show_hotels_id--3175e5c7d102c1dc109933804cb891d3"> Compare hotels </label></div></header><div style="z-index: 1 !important; display: block; align-items: center !important; margin-top: 5px !important; margin-bottom: 5px !important;" class="tp_powered_by"><a style="
display: inline-block !important;
height:16px !important;
background: none !important;
background-color: transparent !important;
border: 0 !important;
box-shadow: none !important;
box-sizing: border-box !important;
color: none !important;
cursor:pointer !important;
margin: 0 !important;
vertical-align: baseline !important;
text-align: left !important;
text-decoration: none !important;
text-indent: 0 !important;
text-transform: none !important;
text-shadow: none !important;
white-space: normal !important;
letter-spacing: 0 !important;
float: none !important;
font: inherit !important;
font-style: normal !important;
font-weight: normal !important;
font-size: 100% !important;
line-height: 1 !important;
padding: 0 !important;
position: initial !important;
" href="//www.travelpayouts.com?marker=319712.poweredby&amp;utm_source=powered_by&amp;utm_medium=widget&amp;utm_campaign=mewtwo" rel="nofollow" target="_blank"><img width="167" height="16" alt="powered_by" src="https://www.travelpayouts.com/powered_by/img/tp.png" style="opacity:0.4;padding:0 5px !important;box-sizing: content-box !important;" onmouseover="this.style['opacity'] = 1" onmouseout="this.style['opacity'] = 0.4"></a></div></section></div></section></div><div class="resize-sensor" style="position: absolute; inset: 0px; overflow: scroll; z-index: -1; visibility: hidden;"><div class="resize-sensor-expand" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: scroll; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0px; top: 0px; width: 824px; height: 247px;"></div></div><div class="resize-sensor-shrink" style="position: absolute; left: 0; top: 0; right: 0; bottom: 0; overflow: scroll; z-index: -1; visibility: hidden;"><div style="position: absolute; left: 0; top: 0; width: 200%; height: 200%"></div></div></div></div><script charset="utf-8" src="//www.travelpayouts.com/widgets/3175e5c7d102c1dc109933804cb891d3.js?v=2175" async="" script-initialized="true" initialized="true"></script>


          </div>
          </div>
     </section>


     
     <!--footer begin -->
<footer id="contact" class="fluid-container bg-dark">
    <div class="container footer-container  d-flex">
            <div class="section1 flex-fill">
                <h2 style="font-size: 30px" class="text-warning pb-3">Send us a message</h2>
                <form class=""  method="POST" action="sentMail.php">
                    <input class="form-control"  type="text" name="fname" placeholder="Enter your full name" required><br>
                    <input class="form-control" type="email" name="email" placeholder="Enter your Email Address" required><br>
                    <textarea style="height: 130px" class="form-control" placeholder="Tell us about Your message" name="message" required></textarea><br>
                
                    <input style="color:white;border-radius:20px;padding:15px" class="text-center bg-success" type="submit" name="submit" value="Send mesage">
                    <br>
                </form>
            </div>
            <div class="section2 flex-fill text-center text-white">
                <h2 style="font-style: italic;font-family: monospace;font-size: 18px">Get the best Taxi Deals</h2>
                <h4 style="font-style: normal;font-family: monospace;font-size: 18px;padding:10px">MWALIMUAIRPORTTRANSFERANDTAXI</h4>
                <H5>5 START RATING</H5>
                <form class="">
                    <img src="images/gal/f.jpg" width="250" height="200"><br><br>
                    <a href="#"><img src="images/pesapal.PNG" width="200" height="50"></a>
                </form>
            </div>
            <div class="section3 flex-fill">
                <h2  class="text-success">Our location</h2>
                <h5 style="font-weight: bold;color:orange;font-size:15px"><i class="fa fa-map" id="phonefa"></i> Gigiri UN Avenue,Nairobi</h5>
                <a href="https://api.whatsapp.com/send?phone=+254 723 234 262 " target="_blank"><i class="fa fa-whatsapp" id="phonefa">
                    
                </i>&nbsp;  +254 723 234 262 </a><br>
                <a style="text-decoration:none" href="mailto:erwachira32@gmail.com" target="_blank">
                    <i class="fa fa-envelope" id="phonefa"></i>&nbsp; erwachira32@gmail.com</a><br>
                    <br><br>
                    <h6 style="font-weight: bold;color:orange;">Leave us a review</h6>
                    <p class="text-white">By sending us a message</p>
</div></div>
<br><br>
<div style="color:white;background-color:black;text-align:center;font-size:10px;padding:40px 0px 15px;" class="final">
    <h5 >
        <a style="padding:15px;text-decoration:none;padding-bottom: 5px" href="#" class="fa fa-facebook-square" attr="facebook icon" target="_blank">
            <a style="padding:15px;text-decoration:none;padding-bottom: 5px" href="#" class="fa fa-twitter"></a>
            <a style="padding:15px;text-decoration:none;padding-bottom: 5px" href="#" class="fa fa-instagram"></a>
    </h5><br>
    <h3 style="font-size: 15px">Copyright © 2022 Mwalimu Airport Transfer and Taxi.</h3>
</div>
</footer>
<div class="whatsapp">
    <a href="https://api.whatsapp.com/send?phone=+254723234262" target="_blank">
     <img src="images/what.jpg"  alt="send us a message via whatsapp" style="position: fixed;border-radius:50px;right: 30px;bottom: 70px;z-index: 10000;height:60px">
     </a>
    </div>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>
     
<script>
    $('#buk').submit(function(e) {
    var formData = new FormData($(this)[0]);
    $.ajax({
    url: "sms.php",
    type: "POST",
    data: formData,
    async: false,
    success: function (data) {
        
        if(data == 1){
          alert("Your Reservation has been received! We'll get back to you shortly.");
          document.getElementById('buk').reset();
        }else{
         alert("There was a problem sending your reservation. Please try again.");
        }
    },
    cache: false,
    contentType: false,
    processData: false
    });
    e.preventDefault();
    });
</script>

<script>
    $('#contact-form').submit(function(e) {
    var formData = new FormData($(this)[0]);
    $.ajax({
    url: "contact.php",
    type: "POST",
    data: formData,
    async: false,
    success: function (data) {
        
        if(data == 1){
          alert("Thanks for sending your message! We'll get back to you shortly.");
          document.getElementById('contact-form').reset();
        }else{
         alert("Error sending your message. Please try again.");
        }
    },
    cache: false,
    contentType: false,
    processData: false
    });
    e.preventDefault();
    });
</script>


<img src="//avsplow.com/a/j.gif?p=web&amp;tv=pixel&amp;e=se&amp;aid=tp_widgets&amp;se_ca=mewtwo&amp;se_ac=proxy_init&amp;co=%7B%22schema%22%3A%22contexts%22%2C%22data%22%3A%5B%7B%22schema%22%3A%22event%22%2C%22data%22%3A%7B%22widget_id%22%3A%223175e5c7d102c1dc109933804cb891d3%22%2C%22trace_id%22%3A%22Zz2b4796083d14429c89603d5-319712%22%2C%22promo_id%22%3A%224238%22%7D%7D%5D%7D" style="position: absolute; top: 0; left: -100px; width: 1px; height: 1px;"></body><div class="mewtwo-modal-wrapper"><div class="mewtwo-modal" role="modal"></div></div></html>